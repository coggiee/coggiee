from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)
# app.config['SQLALCHEMY_DATABASE_URI']='sqlite:////home/lunarmoon/webpi/infodb.db'

# db = SQLAlchemy(app)


# class marin(db.Model):
	# uid = db.Column(db.Integer)
	# did = db.Column(db.Text, primary_key=True)
	# name = db.Column(db.Text)
	
	# def __init__(self, uid, did, name):
		# self.uid = uid
		# self.did = did
		# self.name = name

@app.route('/')
def main():
	return 'Hello World!'

@app.route('/index')
def index():
	return render_template('index.html')

@app.route('/sql_insert', methods=['GET', 'POST'])
def sql_insert():
	
	if request.method == 'POST':
		conn = sqlite3.connect('////home/pi/Downloads/marin/src/oceanlab')
		cursor = conn.cursor()
		
		did = request.form['did']
		uid = request.form['uid']
		name = request.form['name']
		
		try:
			cursor.execute('CREATE TABLE IF NOT EXISTS user (did text primary key, uid text, name text)')
			cursor.execute("INSERT INTO user(did, uid, name) VALUES('"+did+"', '"+uid+"', '"+name+"')")
			#cursor.exectue('INSERT INTO user(did, uid, name) VALUES (?,?,?);', (did, uid, name))
			conn.commit()
			conn.close()
			return render_template('sql_insert.html')
		except:
			print('Error')
			return render_template('sql_insert.html')
	else:
		return render_template('sql_insert.html')
	
	
	
		
if __name__ == '__main__':
	app.run(host='0.0.0.0', port=7777)
